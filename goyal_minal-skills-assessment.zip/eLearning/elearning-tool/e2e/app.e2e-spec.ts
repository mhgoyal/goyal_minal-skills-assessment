import { ElearningToolPage } from './app.po';

describe('elearning-tool App', function() {
  let page: ElearningToolPage;

  beforeEach(() => {
    page = new ElearningToolPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
