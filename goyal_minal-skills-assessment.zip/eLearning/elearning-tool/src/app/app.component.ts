import { Component,OnInit } from '@angular/core';
import {InventoryService} from 'app/app.service'

@Component({
  selector: 'app-root',
  providers: [InventoryService],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  inventoryService:any;
  inventory:any;
  curr_inventory:any;
  pageView: Boolean;
  selectedCourse: any;
  courseCount: number;
  totalCourses: number;
  pages:number[];
  currentPg: number;
  totalPgs:number;
  edit: Boolean;
  createView: Boolean;
  new_course: any;
  errorOccurred:Boolean;
  error:string;

  constructor(private InventoryService: InventoryService){
    this.inventoryService=InventoryService;
    this.pageView=true;
    this.courseCount=5;
    this.currentPg=1;
    this.edit=false;
    this.createView=false;
    this.new_course={};
  }

  //Call to the inventory service that reads the json file
  ngOnInit(){
    this.inventoryService.getInventory().subscribe(res=>this.inventory=res,error=>console.log("Error: ",error),()=>this.load());
  }

  //paginate for page 1 - default
  load(){
    this.paginate(this.courseCount);
  }

  //Calculates no of pages required for courses
  paginate(val){
    this.courseCount=val;
    this.totalCourses=this.inventory.length;
    var pgs=Math.trunc(this.totalCourses/this.courseCount);
    var pgs_mod=this.totalCourses%this.courseCount;
    if(pgs_mod!==0){
      pgs=pgs+1;
    }
    this.totalPgs=pgs;
    this.pages=new Array(pgs);
    for(var i=0;i<pgs;i++)
    this.pages[i]=i+1;
    this.selectInventory();
  }

  //selects requried courses from inventory list for page
  selectInventory(){
    var start=(this.courseCount * (this.currentPg-1));
    var end=start+this.courseCount;
    if(this.courseCount>this.inventory.length)
    end=this.inventory.length;
    this.curr_inventory=this.inventory.slice(start,end);
  }

  //On page navigation, alters the current page
  pageMove(val){
    if(val=="prev"){
      this.currentPg=this.currentPg-1;
    }
    else if(val=="next"){
      this.currentPg=this.currentPg+1;
    }
    else {
      this.currentPg=val;
    }
          this.selectInventory();
  }

  //Hides the course list and displays course details
  courseDetails(course){
    this.pageView=false;
    this.selectedCourse=course;
    this.selectedCourse.time=this.selectedCourse.time/60;
  }

  //function  to render create course view
  createc(){
    this.new_course={graphic:{alt:"",src:""}};
    this.pageView=false;
    this.createView=true;
  }

  //Adds the new course to the inventory
  addCourse(){
    if(this.new_course.id===undefined || this.new_course.title===undefined){
    this.errorOccurred=true;
    this.error="Course Details cannot be empty";
    return;   
    }
    else{
    this.new_course.time=this.new_course.time*60;
    this.new_course.date_created=new Date().toLocaleDateString()+" "+new Date().toLocaleTimeString();
    this.new_course.last_update=this.new_course.date_created;
    this.inventory.push(this.new_course);
    this.pageView=true;
    this.createView=false;
    this.paginate(this.courseCount);
  }
  }

  //removes course from the inventory
  removec(course){
    var index=this.inventory.indexOf(course);
    this.inventory.splice(index,1);
    this.selectInventory();
  }

  //toggles view of course view screen
  updatec(){
    this.edit=false;
  }
}
